package com.example.myapplication

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Отримуємо доступ до текстових полів
        val textViewName = findViewById<TextView>(R.id.textViewName)
        val textViewGroup = findViewById<TextView>(R.id.textViewGroup)
        val buttonChangeText = findViewById<Button>(R.id.buttonChangeText)

        // Програмно змінюємо текст для групи
        textViewGroup.text = "Група:"

        // Функція, яка змінює текст після натискання кнопки
        buttonChangeText.setOnClickListener {
            textViewName.text = "Мачеброда Денис"
            textViewGroup.text = "Група: 4-8"
        }
    }
}